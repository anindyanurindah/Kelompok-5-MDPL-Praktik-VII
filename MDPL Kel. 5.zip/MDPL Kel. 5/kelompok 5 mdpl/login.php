<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- Style -->
    <link rel="stylesheet" href="css/style.css">

    <title>Login dulu yaa</title>
  </head>
  <body>
  

  <div class="half">
    <div class="bg order-1 order-md-2" style="background-image: url('images/bg.png');"></div>
    <div class="contents order-2 order-md-1"  style="background-color: #a7d0cd;">

      <div class="container">
        <div class="row align-items-center justify-content-center" >
          <div class="col-md-6" >
            <div class="form-block" >
              <div class="text-center mb-5" >
              <!-- <p class="mb-4">Lorem ipsum dolor sit amet elit. Sapiente sit aut eos consectetur adipisicing.</p> -->
                <center>
                <img src="images/login.png" style="width: 30%; margin-left: 0%;\">
                </center>
              </div>
              <form action="ceklogin.php" method="post">
                <div class="form-group first">
                  <label for="username">Nomor Induk Karyawan </label>
                  <input type="text" class="form-control" placeholder="Masukkan NIK" name="nik">
                </div>
                <div class="form-group last mb-3">
                  <label for="password">Password</label>
                  <input type="password" class="form-control" placeholder="Masukkan Password" name="password">
                </div>
                <input type="submit" value="login" name="login" class="btn btn-block btn-primary" style="background-color: #1c3d92; color: aliceblue;">
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>

    
  </div>
    
    

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>