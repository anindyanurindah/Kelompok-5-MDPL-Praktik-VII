<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Tabel Admin</title>
    <style>
      footer {
            background-color: #3D0000;
            color: whitesmoke;
            width: 100%;
            text-align: center;
            font-size: 20px;
            position: fixed;
            left: 0;
            bottom: 0;
        } 
    </style>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="styleadmin.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
    <title>Document</title>
    <script src="https://kit.fontawesome.com/e9417b4dbb.js" crossorigin="anonymous"></script>
  </head>
  <body></body>
</html>

  <header>
    <h2>DATA TABEL ADMIN</h2>
  </header>

  <section>
    <nav>
      <div class="picture"></div>
      <div class="btn">
        <button class="btn-logout"><a href="login.php">logout</a></button>
      </div>
    </nav>

    <article>
      <div class="satu">
          <div class="dua">
      <table class="table" class="table" style="text-align: center">
        <thead>
          <tr>
            <th scope="col">NO</th>
            <th scope="col">NAMA</th>
            <th scope="col">NIK</th>
            <th scope="col">JABATAN</th>
            <th scope="col">KETERANGAN</th>
            <th scope="col">ACTION</th>
          </tr>
        </thead>
        <?php 
    include "koneksi.php";
    $no=1;
    $ambildata = mysqli_query($koneksi, "select * from presensi2");
    while ($tampil =mysqli_fetch_array($ambildata)){
        echo"
        <tr>
        <td>$no</td>
        <td>$tampil[nama]</td>
        <td>$tampil[nik_pegawai]</td>
        <td>$tampil[jabatan]</td>
        <td>$tampil[keterangan]</td>
        <td><a href='?kode=$tampil[nik_pegawai]'><i class='fas fa-trash-alt'></i></a></td>
        </tr>
        ";
        $no++;
    }
    ?>
        <!-- <tbody>
          <tr>
            <th>1</th>
            <th>Anindya</th>
            <th>52004111</th>
            <th>Ketum</th>
            <th>Terlambat</th>
            <th><i class="fas fa-trash-alt"></i></th>
          </tr>
          <tr>
            <th>2</th>
            <th>Sayyidan</th>
            <th>52004112</th>
            <th>Waketum</th>
            <th>Tidak Masuk</th>
            <th><i class="fas fa-trash-alt"></i></th>
          </tr>
          <tr>
            <th>3</th>
            <th>Diky</th>
            <th>52004113</th>
            <th>Anggota</th>
            <th>Masuk</th>
            <th><i class="fas fa-trash-alt"></i></th>
          </tr>
          <tr>
            <th>4</th>
            <th>....</th>
            <th>.....</th>
            <th>......</th>
            <th>.....</th>
            <th><i class="fas fa-trash-alt"></i></th>
          </tr>
          <tr>
            <th>5</th>
            <th>.....</th>
            <th>.....</th>
            <th>....</th>
            <th>....</th>
            <th><i class="fas fa-trash-alt"></i></th>
          </tr>
          <tr>
            <th>6</th>
            <th>.....</th>
            <th>.....</th>
            <th>....</th>
            <th>....</th>
            <th><i class="fas fa-trash-alt"></i></th>
          </tr>
          <tr>
            <th>7</th>
            <th>.....</th>
            <th>.....</th>
            <th>....</th>
            <th>....</th>
            <th><i class="fas fa-trash-alt"></i></th>
          </tr>
          <tr>
            <th>8</th>
            <th>.....</th>
            <th>.....</th>
            <th>....</th>
            <th>....</th>
            <th><i class="fas fa-trash-alt"></i></th>
          </tr>
          <tr>
            <th>9</th>
            <th>.....</th>
            <th>.....</th>
            <th>....</th>
            <th>....</th>
            <th><i class="fas fa-trash-alt"></i></th>
          </tr>
          <tr></tr> -->
        </tbody>
      </table>
    </article>
  </section>
  <?php
  if(isset($_GET['kode'])){
    mysqli_query($koneksi, "delete from presensi2 where nik_pegawai='$_GET[kode]'");


    echo "<script language='javascript'>alert('presensi berhasil di hapus');window.location='tabeladmin.php'</script>";
  }



  ?>

  <footer style="background-color: #3D0000; color: white; width: 100%;  text-align: center; font-size: 20px; position: fixed;">
      <span>Copyright © Kelompok 5 MDPL Praktik 2021 UTY</span>
  </footer>

