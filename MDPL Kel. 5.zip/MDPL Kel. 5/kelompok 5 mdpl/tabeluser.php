<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Halaman Data Tabel User</title>

	<style>
	 p {
            text-align: center;
            width: 11%;
	        min-height: 445px;
	        border: 1px solid;
	        float: left;
	        margin: 0%;
	        background-color: #f3d5c0;
            padding: 2%;
        }

     img {
            width: 70%;
	        height: 110px;
         }
     button {
            color: #424242;
            background-color: #f44336;
            font-size: 12px;
            font-weight: bold;
            text-align: center;
            width: 70%;
	        min-height: 40px;
	        border: 1px solid;
        }

     .satu {
     	max-width: 2500px;
     	height: 80vh;
     }

     .dua {
     	height: 100%;
     	overflow: auto;
     }

     h2 {
            text-align: center;
            font-family: 'arial';
            color: #424242;
        }
    th {background: #91b3cc; color: #424242; width: 500px; margin: auto; font-size: 18px; border-collapse: collapse; border: none;}
    table {margin: auto; top: 100px; width: 97%; border: none; font-size: 18px; border-collapse: collapse;}
    .table {background: #ffefcf; color : #424242; padding: 20px; font-family: 'Times New Roman';}
    .table1 {background: #FFE699; color : #424242; padding: 20px; font-family: 'Times New Roman'}
    .table2 {background: #ffefcf; color : #424242; padding: 20px; font-family: 'Times New Roman'}
    .table3 {background: #FFE699; color : #424242; padding: 20px; font-family: 'Times New Roman'}
    .table4 {background: #ffefcf; color : #424242; padding: 20px; font-family: 'Times New Roman'}
    .table5 {background: #FFE699; color : #424242; padding: 20px; font-family: 'Times New Roman'}
    .table6 {background: #ffefcf; color : #424242; padding: 20px; font-family: 'Times New Roman'}
    .table7 {background: #FFE699; color : #424242; padding: 20px; font-family: 'Times New Roman'}
    .nomor {width: 70px; padding: 0px; font-family: 'arial'}
    .nama {width: 350px; padding: 0px; font-family: 'arial'}
    .nik {width: 380px; padding: 0px; font-family: 'arial'}
    .jabatan {width: 380px; padding: 0px; font-family: 'arial'}
    .keterangan {width: 380px; padding: 0px; font-family: 'arial'}

    footer {
    	background-color: #3D0000;
    	margin: auto;
   	    padding: 1.5rem 5rem;
    	color: whitesmoke;
    	max-height: 1px;
    	text-align: center;
    	font-size: 20px;
    }
    </style>

</head>
<body bgcolor="#a7d0cd">
	<h2 align-items= center>DATA TABEL USER</h2>
    <p class="a">
        <img src="images/login.png" />
        <button> <a href="login.php" >Logout</a></button>
    </p>

<div class="satu">
	<div class="dua">
<table border="1" cellspacing=auto class="data">
    <tr>
        <th class="nomor"><h3>No</th></h3>
        <th class="nama"><h3>Nama</th></h3>
        <th class="nik"><h3>NIK</th></h3>
        <th class="jabatan"><h3>Jabatan</th></h3>
        <th class="keterangan"><h3>Keterangan</th></h3>
    </tr>
    <?php 
    include "koneksi.php";
    $no=1;
    $ambildata = mysqli_query($koneksi, "select * from presensi2");
    while ($tampil =mysqli_fetch_array($ambildata)){
        echo"
        <tr>
        <td>$no</td>
        <td>$tampil[nama]</td>
        <td>$tampil[nik_pegawai]</td>
        <td>$tampil[jabatan]</td>
        <td>$tampil[keterangan]</td>
        </tr>
        ";
        $no++;
    }
    ?>


    <!-- <tr>
        <td class="table" align="center">1</td>
        <td class="table" align="center">Budi Purnomo</td>
        <td class="table" align="center">002415342</td>
        <td class="table" align="center">Staff</td>
        <td class="table" align="center">Masuk</td>
    </tr> 
     <tr>
        <td class="table1" align="center">2</td>
        <td class="table1" align="center">Ratna Putri</td>
        <td class="table1" align="center">002415562</td>
        <td class="table1" align="center">Staff</td>
        <td class="table1" align="center">Masuk</td>
    </tr>  
     <tr>
        <td class="table2" align="center">3</td>
        <td class="table2" align="center">Aldi Syahputra</td>
        <td class="table2" align="center">002415543</td>
        <td class="table2" align="center">Staff</td>
        <td class="table2" align="center">Tidak Masuk</td>
    </tr>  
     <tr>
        <td class="table3" align="center">4</td>
        <td class="table3" align="center">Rini Pertiwi</td>
        <td class="table3" align="center">002415189</td>
        <td class="table3" align="center">Staff</td>
        <td class="table3" align="center">Tidak Masuk</td>
    </tr>  
    <tr>
        <td class="table4" align="center">5</td>
        <td class="table4" align="center">Agus Rahman</td>
        <td class="table4" align="center">002415799</td>
        <td class="table4" align="center">Staff</td>
        <td class="table4" align="center">Masuk</td>
    </tr>  
    <tr>
        <td class="table5" align="center">6</td>
        <td class="table5" align="center">Dani Kurniawan</td>
        <td class="table5" align="center">002415487</td>
        <td class="table5" align="center">Staff</td>
        <td class="table5" align="center">Masuk</td>
    </tr> 
    <tr>
        <td class="table6" align="center">7</td>
        <td class="table6" align="center">Toni Pamungkas</td>
        <td class="table6" align="center">002415765</td>
        <td class="table6" align="center">Staff</td>
        <td class="table6" align="center">Tidak Masuk</td>
    </tr> 
    <tr>
        <td class="table7" align="center">8</td>
        <td class="table7" align="center">Nirmala Kencani</td>
        <td class="table7" align="center">002415853</td>
        <td class="table7" align="center">Staff</td>
        <td class="table7" align="center">Masuk</td>
    </tr>  -->
    </div>  
    </table>
</div>
  <footer>
         <span>Copyright by: Kelompok 5 MDPL Praktik 2021 UTY</span>
  </footer>
</body>
</html>