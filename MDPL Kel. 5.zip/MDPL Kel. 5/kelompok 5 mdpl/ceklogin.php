<?php 

// mengaktifkan session pada php
session_start();

// menghubungkan php dengan koneksi database
include 'koneksi.php';

// menangkap data yang dikirim dari form login
$nik = $_POST['nik'];
$password = $_POST['password'];


// menyeleksi data user dengan username dan password yang sesuai
$login = mysqli_query($koneksi,"SELECT * FROM userr WHERE nik='$nik' and password='$password'");
// menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($login);

// cek apakah username dan password di temukan pada database
if($cek > 0){
 
 $data = mysqli_fetch_assoc($login);

 // cek jika user login sebagai admin
 if($data['level']=="admin"){
  // buat session login dan username
  $_SESSION['nik'] = $nik;
  $_SESSION['level'] = "admin";
  // alihkan ke halaman dashboard admin
  header("location:tabeladmin.php");

 // cek jika user login sebagai pegawai
 }else if($data['level']=="karyawan"){
  // buat session login dan username
  $_SESSION['nik'] = $nik;
  $_SESSION['level'] = "karyawan";
  // alihkan ke halaman dashboard pegawai
  header("location:presensi.php");

 }else{

  // alihkan ke halaman login kembali
  header("location:login.php?pesan=gagal");
 } 
}else{
 header("location:login.php?pesan=gagal");
}
?>