<!DOCTYPE html>
<html>
<head>
    <title>Halaman Presensi Karyawan</title>
    <style>
        header {
            justify-content: center;
            color: #424242;
            font-family: 'arial black';
            font-size: 30px;
            font-weight: bold;
            text-align: center;
            width: 81%;
	        min-height: 65px;
	        border: 1px solid;
        	float: right;
	        margin: 0.5%;
	        background-color: #91b3cc;
	        padding: 1%;
        }
        img {
            width: 70%;
	        height: 110px;
        }
        button {
            color: #424242;
            background-color: #f44336;
            font-size: 12px;
            font-weight: bold;
            text-align: center;
            width: 70%;
	        min-height: 40px;
	        border: 1px solid;
        }
        .a {
            text-align: center;
            width: 12%;
	        min-height: 520px;
	        border: 1px solid;
	        float: left;
	        margin: 0.5%;
	        background-color: #f3d5c0;
            padding: 1%;
        }

        .input-group {
            align-items: center;
            position: relative;
            width: 50%;
            margin-bottom: 25px;
        }

        .submit input{
            background-color: royalblue;
            font-size: 14px;
            font-weight: bold;
            text-align: center;
            width: 10%;
            min-height: 40px;
            border: 1px solid;
        }

        .input-group input {
            align-items: center;
            background-color: #ffefcf;
            height: 50px;
            width: 50%;
            padding: 0 10px;
            box-sizing: border-box;
            font-size: 15px;
            border: 1px solid;
            border-radius: none;
            margin: 1%;
        }

        .input-jabatan input {
            float: right;
            align-items: center;
            background-color: #ffefcf;
            height: 50px;
            width: 25%;
            padding: 0 10px;
            box-sizing: border-box;
            font-size: 15px;
            border: 1px solid;
            border-radius: none;
            margin: 1%;
        }

        .input-group span {
            float: center;
            position: all;
            top: -12px;
            left: 20px;
            padding: 0px;
            text-transform: capitalize;
            transition: 0.5s;
        }   

        .input-group input:focus ~ span,
        .input-group input:valid ~ span,
        .input-jabatan input:focus ~ span,
        .input-jabatan input:valid ~ span {
            top: 12px;
            left: 100px;
            font-size: 14px;
            background-color: #ffefcf;
            border: 1px solid;

        }  

        footer {
            background-color: #3D0000;
            color: whitesmoke;
            width: 100%;
            text-align: center;
            font-size: 20px;
            position: fixed;
            left: 0;
            bottom: 0;
        }    

    </style>
    </head>
    <body bgcolor="#a7d0cd">
        
        <header>Presensi Karyawan</header>
        
        <p class="a">
            <img src="images/login.png"/>
            <button><a href="login.php">Logout</a></button>
        </p>


    <form method="post" style="margin-left:20%; margin-top: auto;">
        <div class="input-group">
                <div>
                  <label for="nama">Nama</label>
                  <br>
                  <input type="nama" class="form-control" placeholder="Masukkan Nama anda" name = "nama">
                </div>
                <div>
                  <label for="username">Nomor Induk Karyawan </label>
                  <br>
                  <input type="text" class="form-control" placeholder="Masukkan NIK anda" name = "nik_pegawai">
                </div>
                <div>
                  <label for="password">Jabatan</label>
                  <br>
                  <input type="Jabatan" class="form-control" placeholder="Masukkan Jabatan anda" name = "jabatan">
                </div>
                </div>
            <div style="font-size:20px; margin-left:20%;">
                    <p style="margin-bottom: 1%;">Keterangan:</p>
                    <input type="radio" id="html" name="keterangan" value="masuk">
                    <label for="html">Masuk</label><br>
                    <input type="radio" id="css" name="keterangan" value="terlambat">
                    <label for="css">Terlambat</label><br>
                    <input type="radio" id="javascript" name="keterangan" value="tidak masuk">
                    <label for="javascript">Tidak Masuk</label>
            </div>
            <br>
            
        <input type="submit" value="Submit" name="submit" class="btn btn-block btn-primary" style="background-color: #1c3d92; color: aliceblue; width: 10%; height: 30px; margin-left:30%;">
        
    </form>
</body>
<?php
    include "koneksi.php";

    if(isset($_POST['submit'])){
        mysqli_query($koneksi, "insert into presensi2 set
        nama = '$_POST[nama]',
        nik_pegawai = '$_POST[nik_pegawai]',
        jabatan = '$_POST[jabatan]',
        keterangan = '$_POST[keterangan]'");

        echo "<script language='javascript'>alert('presensi berhasil dilakukan');window.location='tabeluser.php'</script>";

    }

?>
    <footer>
         <span>Copyright © Kelompok 5 MDPL Praktik 2021 UTY</span>
    </footer>
      
</html>
        
